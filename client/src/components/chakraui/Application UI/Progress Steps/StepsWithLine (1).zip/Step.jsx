import { Box } from '@chakra-ui/react'
import * as React from 'react'

export const Step = (props) => {
  const { isActive, ...boxProps } = props
  return (
    <Box
      flex="1"
      h="2"
      bg={isActive ? 'accent' : 'border'}
      borderRadius="base"
      transition="background 0.2s"
      {...boxProps}
    />
  )
}
