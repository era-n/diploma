import {
  Button,
  Container,
  Divider,
  Heading,
  Input,
  Stack,
  useBreakpointValue,
} from '@chakra-ui/react'
import * as React from 'react'
import { Logo } from './Logo'
import { GoogleIcon } from './ProviderIcons'

export const App = () => (
  <Container
    maxW="md"
    py={{
      base: '12',
      md: '24',
    }}
  >
    <Stack spacing="8">
      <Stack spacing="6" align="center">
        <Logo />
        <Heading
          size={useBreakpointValue({
            base: 'xs',
            md: 'sm',
          })}
        >
          Log in to your account
        </Heading>
      </Stack>
      <Stack spacing="6">
        <Button variant="secondary" leftIcon={<GoogleIcon boxSize="5" />} iconSpacing="3">
          Continue with Google
        </Button>
        <Divider />
        <Stack spacing="4">
          <Input placeholder="Enter your email" />
          <Button variant="primary">Continue with email</Button>
        </Stack>
      </Stack>
      <Button variant="link" colorScheme="blue" size="sm">
        Continue using Single Sign-on (SSO)
      </Button>
    </Stack>
  </Container>
)
